package com.example.ex1

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var textView: TextView
    private lateinit var buttonChangeFont: Button
    private lateinit var buttonChangeColor: Button

    private var fontToggle = false
    private var colorIndex = 0

    // Define multiple colors
    private val colors = listOf(
        Color.RED,
        Color.BLUE,
        Color.GREEN,
        Color.MAGENTA,
        Color.CYAN,
        Color.parseColor("#FFA500") // Orange
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textView = findViewById(R.id.textView)
        buttonChangeFont = findViewById(R.id.buttonChangeFont)
        buttonChangeColor = findViewById(R.id.buttonChangeColor)

        buttonChangeFont.setOnClickListener {
            if (!fontToggle) {
                textView.setTypeface(null, Typeface.BOLD_ITALIC)
            } else {
                textView.setTypeface(null, Typeface.NORMAL)
            }
            fontToggle = !fontToggle
            Toast.makeText(this, "Font changed!", Toast.LENGTH_SHORT).show()
        }

        buttonChangeColor.setOnClickListener {
            textView.setTextColor(colors[colorIndex])
            colorIndex = (colorIndex + 1) % colors.size
            Toast.makeText(this, "Color changed!", Toast.LENGTH_SHORT).show()
        }
    }
}
